README FOR OOSE ASSIGNMENT 2020 Semester 1
Author : Jason Luppnow - 18818835
Date Created: 31/05/2020

To Compile:
    Run ant within the assignment folder

To run: 
    cd Dist
    java -Jar Assignment.jar

Notes:
    This is best viewed in fullscreen so all the strings display to their fullest.