/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         HealingPotionStrategy.java                                    *
* Purpose:          One of the 2 Potion Strategies, responsible for the Main      *
*                   Character using a Healing Potion.   						  *                       
* Unit:             OOSE                                                          *
* Last Modified:    23/05/2020                                                    *
**********************************************************************************/
package Controller.BattleStrategy.PotionStrategy;

//Import Custom Packages
import Model.MainCharacter;
import Model.RoundData;
import Model.Item.Potion;
import Model.Enemy.Enemy;

public class HealingPotionStrategy implements PotionStrategy
{
	/*******************************************************************************
	* Submodule: usePotion                                                         *
	* Import:    gameCharacter (MainCharacter), enemy (Enemy), potion (Potion)     *
	* Export:    None                                                              *
	* Assertion: Overriding Parent usePotion as part of Strategy Pattern.          *
	*******************************************************************************/
	@Override
	public void usePotion(MainCharacter gameCharacter, Enemy enemy, Potion potion, RoundData round)
	{
		//Get the Main Character's health.
		int currentHealth = gameCharacter.getCurrentHealth();
		
		//Get the Main Character's Max health.
		int maxHealth = gameCharacter.getMaxHealth();
			
		//Check if the health is full.
		if (currentHealth < maxHealth)
		{
			//Get the amount healed.
			int healedAmount = potion.calcEffect();
			
			//Heal the character.
			gameCharacter.heal(healedAmount);
			
			//Adds these actions to the round log.
			round.addAction("You drink the " + potion.getItemName());
			round.addAction("As you drink the potion you feel your vitality return, your insides warm and you strength returns.");
			round.addAction("You have recovered " + healedAmount + " health points. ");
		}
		else
		{
			//Adds the action to round log.
			round.addAction("You gulp the potion down...  But besides the taste of cherry lingering you don't feel any difference.");
		}
	}
}