/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         PotionStrategy.java                                           *
* Purpose:          Interface for the Strategy Pattern.    						  *
* Unit:             OOSE                                                          *
* Last Modified:    20/05/2020                                                    *
**********************************************************************************/
package Controller.BattleStrategy.PotionStrategy;

//Import Custom Packages
import Model.MainCharacter;
import Model.RoundData;
import Model.Item.Potion;
import Model.Enemy.Enemy;

public interface PotionStrategy
{
	public void usePotion(MainCharacter gameCharacter, Enemy enemy, Potion potion, RoundData round);	//Implicitly Public Abstract
}