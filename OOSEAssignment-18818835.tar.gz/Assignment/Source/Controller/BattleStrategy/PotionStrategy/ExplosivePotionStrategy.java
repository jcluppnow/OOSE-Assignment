/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         ExplosivePotionStrategy.java                                  *
* Purpose:          One of the 2 Potion Strategies, responsible for the Main      *
*                   Character using a Explosive Potion against the enemy.    	  *                       
* Unit:             OOSE                                                          *
* Last Modified:    20/05/2020                                                    *
**********************************************************************************/
package Controller.BattleStrategy.PotionStrategy;

//Import Custom Packages
import Model.MainCharacter;
import Model.RoundData;
import Model.Item.Potion;
import Model.Enemy.Enemy;

public class ExplosivePotionStrategy implements PotionStrategy
{
	/*******************************************************************************
	* Submodule: usePotion                                                         *
	* Import:    gameCharacter (MainCharacter), enemy (Enemy), potion (Potion)     *
	* Export:    None                                                              *
	* Assertion: Overriding Parent usePotion as part of Strategy Pattern.          *
	*******************************************************************************/
	@Override
	public void usePotion(MainCharacter gameCharacter, Enemy enemy, Potion potion, RoundData round)
	{
		//Calculate the damage the potion will do.
		int potionDamage = potion.calcEffect();
		
		//Get the enemie's defence.
		int enemyDefence = enemy.getDefence();
		
		//Adds the action to round log.
		round.addAction("You threw the potion at the " + enemy.getName() + ".");
		
		//Check if the attack hits.
		if (potionDamage > enemyDefence)
		{
			//Calculate the damage taken after damage reductions.
			int damageTaken = potionDamage - enemyDefence;
			
			//Adds the action to round log.
			round.addAction("The potion shatters against the " + enemy.getName() + " and you hear it " + enemy.getNoise() + " in pain.");
			
			//Adds the action to round log.
			round.addAction("You dealt " + damageTaken + " Explosive damage and left the " + enemy.getName() + " covered in shrapnel and soot.");
		}
		else
		{
			//Adds the action to round log.
			round.addAction("You watch as the potion arcs towards the enemy who sees it coming and has time to sidestep the obvious attack.");
		}	
	}		
}