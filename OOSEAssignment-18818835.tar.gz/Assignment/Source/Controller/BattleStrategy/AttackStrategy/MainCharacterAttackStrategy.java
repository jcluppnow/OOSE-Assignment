/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         MainCharacterAttackStrategy.java                              *
* Purpose:          One of the 2 Attack Strategies, responsible for the Main       *
*                   Character attacking the enemy.								  *                       
* Unit:             OOSE                                                          *
* Last Modified:    20/05/2020                                                    *
**********************************************************************************/
package Controller.BattleStrategy.AttackStrategy;

//Import Custom Packages
import Model.MainCharacter;
import Model.RoundData;
import Model.Item.Weapon;
import Model.Enemy.Enemy;


public class MainCharacterAttackStrategy implements AttackStrategy
{
	/*******************************************************************************
	* Submodule: attack                                                            *
	* Import:    gameCharacter (MainCharacter), enemy (Enemy)                      *
	* Export:    None                                                              *
	* Assertion: Overriding Parent Attack as part of Strategy Pattern.             *
	*******************************************************************************/
	@Override
	public void attack(MainCharacter gameCharacter, Enemy enemy, RoundData round)
	{		
		//Get the Current Weapon.
		Weapon weapon = gameCharacter.getWeapon();
		
		//Calculate the main character's damage.
		int mainCharacterAttack = gameCharacter.getDamage();
		
		//Calculate the enemies defence.
		int enemyDefence = enemy.getDefence();
		
		//Adds the action to round log.
		round.addAction("You attacked the " + enemy.getName() + " with your " + weapon.getItemName() + ".");
		
		//Check if the attack hits.
		if (mainCharacterAttack > enemyDefence)
		{
			//Calculate the damage after damage reductions.
			int damageTaken = mainCharacterAttack - enemyDefence;
			
			//Reduce the enemies health.
			enemy.takeDamage(damageTaken);
			
			//Adds the action to round log.
			round.addAction("The " + enemy.getName() + " took " + damageTaken + " damage.");
		}
		else
		{
			//Adds the action to round log.
			round.addAction("The " + enemy.getName() + " seemed unharmed. ");
		}
	}
			
}