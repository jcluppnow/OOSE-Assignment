/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         EnemyAttackStrategy.java                        			  *
* Purpose:          One of the 2 Attack Strategies, responsible for the Enemy     *
*                   attacking the Main Character.								  *                       
* Unit:             OOSE                                                          *
* Last Modified:    20/05/2020                                                    *
**********************************************************************************/
package Controller.BattleStrategy.AttackStrategy;

//Import Custom Packages
import Model.MainCharacter;
import Model.RoundData;
import Model.Enemy.Enemy;

public class EnemyAttackStrategy implements AttackStrategy
{
	/*******************************************************************************
	* Submodule: attack                                                            *
	* Import:    gameCharacter (MainCharacter), enemy (Enemy)                      *
	* Export:    None                                                              *
	* Assertion: Overriding Parent Attack as part of Strategy Pattern.             *
	*******************************************************************************/
	@Override
	public void attack(MainCharacter gameCharacter, Enemy enemy, RoundData round)
	{
		//Get the Enemies Damage
		int enemyAttack = enemy.getDamage();
		
		//Get the gameCharacter's defence
		int gameCharacterDefence = gameCharacter.getDefence();
		
		//Check if the enemies ability has been triggered.
		if (enemy.hasAbilityTriggered() == true)
		{
			//Get the enemies attack when a Special Ability is triggered.
			enemyAttack = enemy.triggerSpecialAbility();
			//Add this action to the round log.
			round.addAction(enemy.getSpecialAbilityString());
			
			//Check if the attack hit.
			if (enemyAttack > gameCharacterDefence)
			{
				//Calculate the damage after damage reductions.
				int damageTaken = enemyAttack - gameCharacterDefence;
				//Add this action to the round log.
				round.addAction("Causing " + damageTaken + " damage.");
				//Reduce the main characters health.
				gameCharacter.takeDamage(damageTaken);
			}
			else
			{
				//This happens if the damage is withstood. Add the action to round log.
				round.addAction("You braced yourself and withstood the damage.\n");
			}
			
			//Only has to occur because of Ogre.
			//But could for future extensibility enable any enemy to have a second attack.
			if (enemy.hasSecondAttack() == true)
			{
				//Add the action to round log.
				round.addAction("The " + enemy.getName() + " caught you unaware and took a second attack. ");
				
				//Calculate the damage.
				enemyAttack = enemy.triggerSpecialAbility();
				
				//Get the mainCharacters defence.
				gameCharacterDefence = gameCharacter.getDefence();
				
				//Check if the attack hits.
				if (enemyAttack > gameCharacterDefence)
				{
					//Calculates damage after damage reduction.
					int damageTaken = enemyAttack - gameCharacterDefence;
					
					//Adds the action to round log.
					round.addAction("Causing " + damageTaken + " damage.");
					
					//Reduce the main characters health.
					gameCharacter.takeDamage(damageTaken);
				}
				else
				{
					//Adds the action to round log.
					round.addAction("You managed to recover and dodge the second attack. ");
				}
			}
		}
		else
		{
			//Adds the action to round log.
			round.addAction("The " + enemy.getName() + enemy.getAttackType());
			
			//Check if the attack hits.
			if (enemyAttack > gameCharacterDefence)
			{
				//Calculate the damage after damage reduction.
				int damageTaken = enemyAttack - gameCharacterDefence;
				
				//Adds the action to round log.
				round.addAction("Causing " + damageTaken + " damage.");
				
				//Reduce the main characters health.
				gameCharacter.takeDamage(damageTaken);
				
			}
			else
			{
				//Adds the action to round log.
				round.addAction("You braced yourself and withstood the damage. ");
			}
		}	
	}
			
}