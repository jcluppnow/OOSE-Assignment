/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         AttackStrategy.java                                           *
* Purpose:          Interface for the Strategy Pattern.    						  *
* Unit:             OOSE                                                          *
* Last Modified:    20/05/2020                                                    *
**********************************************************************************/
package Controller.BattleStrategy.AttackStrategy;

//Import Custom Packages
import Model.MainCharacter;
import Model.RoundData;
import Model.Enemy.Enemy;

public interface AttackStrategy
{
	public void attack(MainCharacter gameCharacter, Enemy enemy, RoundData round);	//Implicitly Public Abstract
}