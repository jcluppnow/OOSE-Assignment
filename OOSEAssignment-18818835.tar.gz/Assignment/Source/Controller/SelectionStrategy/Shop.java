/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         Shop.java		                                              *
* Purpose:          One of the 5 Strategies, responsible for all Shop Activities. *
* Unit:             OOSE                                                          *
* Last Modified:    27/04/2020                                                    *
**********************************************************************************/
package Controller.SelectionStrategy;

//Import Custom Packages
import Controller.Exceptions.CreateItemException;
import Controller.OutputController;
import Controller.Factories.*;
import Model.MainCharacter;
import Model.Item.*;

//Import Java Packages
import java.util.*;
import java.util.regex.PatternSyntaxException;

public class Shop implements Selection
{	
	private ArrayList<String> Inventory;
	private OutputController oc;
	private MainCharacter gameCharacter;
	private ItemFactory itemFactory;
	private EnchantmentFactory enchantmentFactory;
	
	/*******************************************************************************
	* Submodule: Shop                                                              *
	* Import:    inInventory (ArrayList<String>), inUI (UserInterface),            *
	*            inGameCharacter (MainCharacter)                                   *
	* Export:    None                                                              *
	* Assertion: Alternate Constructor for Shop.                                   *
	*******************************************************************************/
	public Shop(ArrayList<String> inInventory, OutputController inOC, MainCharacter inGameCharacter, ItemFactory inIF, EnchantmentFactory inEF)
	{
		oc = inOC;
		Inventory = inInventory;
		gameCharacter = inGameCharacter;
		itemFactory = inIF;
		enchantmentFactory = inEF;
	}
	
	/*******************************************************************************
	* Submodule: doSelection                                                       *
	* Import:    None                                                              *
	* Export:    None                                                              *
	* Assertion: Overriding Parent Selection as a part of Strategy Pattern.        *
	*******************************************************************************/
	@Override
	public void doSelection()
	{
		int menuChoice;
		menuChoice = oc.getChoice("\n+=====================+\n|  (1) Purchase Item  | \n|  (2) Sell Item      |\n|  (3) Exit           |\n+=====================+");
		
		//Menu for selling or purchasing
		switch (menuChoice)
		{
			case 1:
				startPurchaseItem();
				break;
				
			case 2:
				startSellingItem();
				break;
				
			case 3:
				oc.printString("\nLeaving Shop.");
				break;
				
			default:
				oc.printString("Invalid Menu Selection - Returning to Main Menu.");
		}
	}
	
	/*******************************************************************************
	* Submodule: startPurchaseItem                                                 *
	* Import:    None                                                              *
	* Export:    None                                                              *
	* Assertion: Starts the purchasing of the item. 						       *
	*******************************************************************************/
	public void startPurchaseItem()
	{
		boolean exit = false;
	
		int choice;
		while(exit == false)
		{
			//Get the choice of item to buy
			choice = oc.displayShop(Inventory);
			if (choice == 0)
			{
				exit = true;
			}
			else
			{
				try
				{
					//Start purchase check
					purchaseItem(choice);
				}
				catch (IndexOutOfBoundsException invalidChoice)
				{
					oc.printString("\n\u001b[31mInvalid Choice - Shop. \n\u001b[0m");
				}
			}
		}
	}
	
	/*******************************************************************************
	* Submodule: startSellingItem                                                  *
	* Import:    None                                                              *
	* Export:    None                                                              *
	* Assertion: Starts the selling of the item.							       *
	*******************************************************************************/
	public void startSellingItem()
	{
		int choice;	
		boolean exit = false;

		while(exit == false)
		{
			//Display inventory and get choice to sell
			oc.displayCharacterInventory(gameCharacter.getInventory());
			choice =  oc.getChoice("What would  you like to sell? \n0 to exit.");
			if (choice == 0)
			{
				exit = true;
			}
			else
			{
				try
				{
					//Start the selling
					sellItem(choice);
				}
				catch (IndexOutOfBoundsException invalidChoice)
				{
					oc.printString(invalidChoice.getMessage());
					oc.printString("\n\u001b[31mInvalid Choice - Shop. \n\u001b[0m");
				}
			}
		}
	}
	
	/*******************************************************************************
	* Submodule: purchaseItem                                                      *
	* Import:    choice (Integer)                                                  *
	* Export:    None                                                              *
	* Assertion: Responsible for purchasing an item.                               *
	*******************************************************************************/
	public void purchaseItem(int choice)
	{
		Item newItem = null;
		String item = Inventory.get(choice-1);						//Need to subtract 1 to conform with 0 based indexing.
		String[] parts;
		try
		{
			//Split the line
			parts = item.split(",");
			//Get the funds to check if valid funds
			int characterFunds = gameCharacter.getFunds();
			
			try
			{
				//Split item
				//Check if its an enchantment
				//If it is wrap the main weapon with it
				//Decrease gold
				if (parts[0].equals("Enchantment"))
				{
					String enchantment = item;							//Converted to enchantment so I don't confuse myself later.
					//Get the item price.
					String costString = parts[2].trim();
					try
					{
						//Splits 'Cost: price' recieves the price and trims any whitespace just in case.
						int cost = Integer.parseInt(((costString.split(" "))[1]).trim());		
						if (cost <= characterFunds)
						{
							enchantmentFactory.CreateEnchantment(enchantment, gameCharacter); 	
							gameCharacter.decreaseGold(cost);
						}
						else
						{
							oc.printString("\n\u001B[31m\nInvalid Funds - Need " + (cost - characterFunds) + " more gold. \u001B[0m");
						}
							
					}
					catch (NumberFormatException nfe)
					{
						//NFE is thrown by parseInt
						oc.printString("\nInvalid Format for Cost - Shop - Enchantment.\n");
					}					
				}
				else
				{
					newItem = itemFactory.CreateItem(item);
					int cost = newItem.getCost();
					if (cost <= characterFunds)
					{
						gameCharacter.addToInventory(newItem);
						gameCharacter.decreaseGold(cost);
					}
					else
					{
						oc.printString("\u001B[31m Invalid Funds - Need " + (cost - characterFunds) + " more gold. \u001B[0m");
					}
				}
			}
			catch (CreateItemException cie)
			{
				oc.printString("Failed to create Item.");
			}
		}
		catch (PatternSyntaxException pse)
		{
			oc.printString("Invalid Split Regex - Syntax is Invalid.");
		}	
	}
	/*******************************************************************************
	* Submodule: sellItem                                                          *
	* Import:    choice (Integer)                                                  *
	* Export:    None                                                              *
	* Assertion: Sells an item if it isn't equipped.						       *
	*******************************************************************************/
	public void sellItem(int choice)
	{
		//Retrieve the item
		Item itemToBeSold = gameCharacter.getItemFromInventory(choice-1);
		//Retrieve identifiers
		int itemIdentifier = itemToBeSold.getIdentifier();
		int mainWeaponIdentifier = gameCharacter.getWeaponSerialNumber();
		int mainArmourIdentifier = gameCharacter.getArmourSerialNumber();

		//Check if not equipped
		if (itemIdentifier == mainWeaponIdentifier)
		{
			oc.printString("Can't sell this Weapon as it's equipped.");
		}
		else if (itemIdentifier == mainArmourIdentifier)
		{
			oc.printString("Can't sell this piece of armour as it's equipped.");
		}
		else
		{
			//Sell the item for half original price.
			itemToBeSold = gameCharacter.getInventory().remove(choice-1);
			int itemCost = itemToBeSold.getCost();
			itemCost = itemCost / 2;
			gameCharacter.increaseGold(itemCost);
			oc.printString("You sold the " + itemToBeSold.getItemName() + " for " + itemCost + " gold.");
		}
	}	
}