/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         StartBattle.java                                              *
* Purpose:          One of the 5 Strategies, responsible for All Battle 		  *
* 					Activities.													  *  
* Unit:             OOSE                                                          *
* Last Modified:    27/04/2020                                                    *
**********************************************************************************/
package Controller.SelectionStrategy;

//Import Custom Packages
import Controller.OutputController;
import Controller.BattleStrategy.AttackStrategy.*;
import Controller.BattleStrategy.PotionStrategy.*;
import Controller.Factories.EnemyFactory;
import Controller.Factories.RoundFactory;
import Model.RoundData;
import View.*;
import Model.MainCharacter;
import Model.Enemy.Enemy;
import Model.Item.Potion;
import Model.Item.Item;

//Import Java Packages
import java.util.*;

public class StartBattle implements Selection, MainCharacterObserver, EnemyObserver
{
	private HashMap<Integer, AttackStrategy> attackStrategies;
	private HashMap<Integer, PotionStrategy> potionStrategies;
	private ArrayList<RoundData> combatLog;
	private EnemyFactory enemyFactory;
	private RoundFactory roundFactory;
	private Enemy enemy;
	private String enemyString;
	private String gameCharacterString;
	private MainCharacter gameCharacter;
	private OutputController oc;
	private UserInterface ui;
	private boolean characterAlive;
	private boolean enemyAlive;
	private int roundNumber;
	
	/*******************************************************************************
	* Submodule: StartBattle                                                       *
	* Import:    inGameCharacter (MainCharacter), inUI (UserInterface)             *
	* Export:    None                                                              *
	* Assertion: Alternate Constructor for StartBattle.					           *
	*******************************************************************************/
	public StartBattle(MainCharacter inGameCharacter, EnemyFactory inEF, RoundFactory inRF, MainCharacterAttackStrategy mainCharacterAttackStrategy, EnemyAttackStrategy enemyAttackStrategy, HealingPotionStrategy healingPotionStrategy, ExplosivePotionStrategy explosivePotionStrategy, OutputController inOC)
	{
		//Create Attack Strategies
		attackStrategies = new HashMap<Integer, AttackStrategy>();
		attackStrategies.put(1, mainCharacterAttackStrategy);
		attackStrategies.put(2, enemyAttackStrategy);
		
		//Create Potion Strategies
		potionStrategies = new HashMap<Integer, PotionStrategy>();
		potionStrategies.put(1, healingPotionStrategy);
		potionStrategies.put(2, explosivePotionStrategy);
		
		//Initialize the other fields via Dependency Injection.
		combatLog = new ArrayList<RoundData>();
		gameCharacter = inGameCharacter;
		ui = new UserInterface(gameCharacter);
		gameCharacterString = inGameCharacter.toString();
		enemyString = "";
		enemyFactory = inEF;
		roundFactory = inRF;
		characterAlive = true;
		enemyAlive = false;
		roundNumber = 1;
		oc = inOC;
	}
	
	/*******************************************************************************
	* Submodule: doSelection                                                       *
	* Import:    None                                                              *
	* Export:    None                                                              *
	* Assertion: Overriding Parent Selection as a part of Strategy Pattern.        *
	*******************************************************************************/
	@Override
	public void doSelection()
	{	
		//Restart the Round Data.
		roundNumber = 1;
		combatLog.clear();
		
		boolean validRound = false;
		boolean problemEncountered = false;
		System.out.print("\033[H\033[2J");			//Clear the screen
		this.enemy = enemyFactory.CreateEnemy();	//Generate the enemy
		enemyString = enemy.battleString();			//Set the Enemy Display String
					
		//Add Start Battle As an Observer to the Enemy.
		enemy.add(this);
		
		//Add Start Battle as an Observer to the Main Character.
		gameCharacter.add(this);
		
		enemyAlive = true;
		
		//Initial Display of the Character/Enemy Statistics
		System.out.println(gameCharacterString);
		System.out.println(enemyString);
		while ((characterAlive == true) && (enemyAlive == true) && (problemEncountered == false))
		{
			RoundData round = roundFactory.CreateDefaultRound(roundNumber);
			if (round == null)			//Check if Round was created properly
			{
				oc.printString("Problem with round, closing battle prematurely.");
				problemEncountered = true;
			}
			else
			{
				do
				{
					String message = "\n+==============================+\n|  What would you like to do?  |\n+==============================+\n|  (1) Attack.                 |\n|  (2) Use a Potion.           |\n|  (3) Display Log.            |\n+==============================+";
					int choice = oc.getChoice(message);
					
					switch (choice)
					{
						case 1:
							//Attack - Do the MainCharacterAttackStrategy then the EnemyAttackStrategy
							AttackStrategy firstStrategy = attackStrategies.get(1);
							AttackStrategy secondStrategy = attackStrategies.get(2);
							
							firstStrategy.attack(gameCharacter, enemy, round);
							secondStrategy.attack(gameCharacter, enemy, round);
							combatLog.add(round);
							validRound = true;
							break;
							
						case 2:
							//Display the inventory.
							String messageTwo = "Choose a Potion";
							int potionChoice;
							oc.displayCharacterInventory(gameCharacter.getInventory());
							potionChoice = oc.getChoice(messageTwo);
							
							try
							{
								//Subtract one to make it suitable for 0 based indexing.
								Item item = gameCharacter.getItemFromInventory(potionChoice-1);
								if (item.getItemType().equals("Potion"))
								{
									//Justifiable downcasting. I can guarantee this is a potion and would have no other way of calling potions methods.
									Potion potion = (Potion) item;
									if (potion.getType() == 'H')
									{
										//Use a healing potion
										PotionStrategy potionStrategy = potionStrategies.get(1);
										potionStrategy.usePotion(gameCharacter, enemy, potion, round);
										//Subtract one ot make it suitable for 0 based indexing.
										gameCharacter.removeFromInventory(potionChoice - 1);
										secondStrategy = attackStrategies.get(2);
										secondStrategy.attack(gameCharacter, enemy, round);
										combatLog.add(round);
										validRound = true;
		
									}
									else if (potion.getType() == 'D')
									{
										//Use a potion
										PotionStrategy potionStrategy = potionStrategies.get(2);
										potionStrategy.usePotion(gameCharacter, enemy, potion, round);
										//Subtract one to make it suitable for 0 based indexing.
										gameCharacter.removeFromInventory(potionChoice - 1);
										secondStrategy = attackStrategies.get(2);
										secondStrategy.attack(gameCharacter, enemy, round);
										combatLog.add(round);
										validRound = true;
									}
									else
									{
										oc.printString("\u001b[31mInvalid Potion - StartBattle. \u001b[0m");
										validRound = false;
									}
								}
								else
								{
									oc.printString("\u001b[31mItem is not a Potion. \u001b[0m");
									validRound = false;
								}
							}
							catch (IndexOutOfBoundsException invalidChoice)
							{
								oc.printString("\u001b[31mInvalid Choice from Inventory. \u001b[0m");
							}
							break;
						
						case 3:
							displayCombatLog();
							validRound = false;
							oc.continueScreen();
							break;
							
						default:
							oc.printString("\u001b[31mInvalid Choice - " + choice + "\u001b[0m");
							validRound = false;
					}
				}
				while (validRound != true);
				oc.printString("\033[H\033[2J");
				oc.printString(gameCharacterString);
				oc.printString(enemyString);
				displayRound(round);
				oc.printString("Round " + roundNumber + " Over!");
				oc.continueScreen();
				roundNumber++;
			}
		}
		if (problemEncountered == false)
		{
			postWinAction(enemy);
		}
	}
	
	/*******************************************************************************
	* Submodule: postWinAction                                                     *
	* Import:    enemy (Enemy)                                                     *
	* Export:    None                                                              *
	* Assertion: Display what happens when win.								       *
	*******************************************************************************/
	public void postWinAction(Enemy enemy)
	{
		//Give the Reward 
		if (enemyAlive == false)
		{
			addReward(enemy);
		}
		
		//Game Over
		if (characterAlive == false)
		{
			gameOver(enemy);
		}
	}
	
	/*******************************************************************************
	* Submodule: addReward                                                         *
	* Import:    enemy (Enemy) 													   *
	* Export:    None                                                              *
	* Assertion: Add the reward to the gold reserve. 						       *
	*******************************************************************************/
	public void addReward(Enemy enemy)
	{
		int reward = enemy.getReward();
		int funds = gameCharacter.getFunds();
		int total = funds + reward;
		int healthRecovered = ((int)(gameCharacter.getCurrentHealth() * 1.5)) - gameCharacter.getCurrentHealth();
		
		oc.printString("\u001b[32mCongratulations you defeated the Enemy.");
		oc.printString("You earned " + reward + " gold from defeating the " + enemy.getName() + ".");
		oc.printString("Totals Funds: " + total);
		oc.printString("You have recovered " + healthRecovered + " health.\u001b[0m\n");
		gameCharacter.increaseGold(reward);
		gameCharacter.heal(healthRecovered);	
	}
	
	/*******************************************************************************
	* Submodule: gameOver                                                          *
	* Import:    None                                                              *
	* Export:    None                                                              *
	* Assertion: Set the game to over. As the character died.                      *
	*******************************************************************************/
	public void gameOver(Enemy enemy)
	{
		gameCharacter.setAlive(false);
		oc.printString("\u001b[31mUnfortunately you lost your life to the " + enemy.getName() + "\u001b[0m");
		oc.printString("\u001b[31mYou can't continue any further. GAME OVER.\u001b[0m");
	}
	
	/*******************************************************************************
	* Submodule: updateMainCharacter                                               *
	* Import:    None                                                              *
	* Export:    None                                                              *
	* Assertion: Reset the character string as a change has occurred to Main       *
	*            Character.														   *
	*******************************************************************************/
	public void updateMainCharacter()
	{
		gameCharacterString = gameCharacter.toString();
		if (gameCharacter.getCurrentHealth() == 0)
		{
			characterAlive = false;
		}
	}
	
	/*******************************************************************************
	* Submodule: updateEnemy                                                       *
	* Import:    None                                                              *
	* Export:    None                                                              *
	* Assertion: Update Enemy String as a Change has occurred to enemy health.     *
	*******************************************************************************/
	public void updateEnemy()
	{
		enemyString = enemy.battleString();
		if (enemy.getCurrentHealth() == 0)
		{
			enemyAlive = false;
		}
	}
	
	/*******************************************************************************
	* Submodule: displayCombatLog                                                  *
	* Import:    None                                                              *
	* Export:    None                                                              *
	* Assertion: Displays any actions that have occurred so far.			       *
	*******************************************************************************/
	public void displayCombatLog()
	{
		if (combatLog.isEmpty())
		{
			oc.printString("No combat has yet occurred.");
		}
		else
		{
			oc.printString("Combat Log.\n");
			System.out.print("\033[H\033[2J");  
			for (RoundData round : combatLog)
			{
				displayRound(round);
			}
		}
	}
	
	/*******************************************************************************
	* Submodule: displayRound                                                      *
	* Import:    round (RoundData)                                                 *
	* Export:    None                                                              *
	* Assertion: Displays the round passed in.								       *
	*******************************************************************************/
	public void displayRound(RoundData round)
	{
		oc.printString("\nRound " + round.getRoundNumber() + " Combat Log:");
		oc.printString(round.toString() + "\n");	
	}	
}