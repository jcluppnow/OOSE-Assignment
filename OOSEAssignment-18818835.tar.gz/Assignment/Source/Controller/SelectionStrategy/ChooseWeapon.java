/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         ChooseWeapon.java                                             *
* Purpose:          One of the 5 Strategies, responsible for equipping a Weapon.  *                                              
* Unit:             OOSE                                                          *
* Last Modified:    27/04/2020                                                    *
**********************************************************************************/
package Controller.SelectionStrategy;

//Import Custom Packages
import Controller.Exceptions.MainCharacterException;
import Controller.OutputController;
import Model.MainCharacter;

//Import Java Packages
import java.util.*;

public class ChooseWeapon implements Selection
{
	private MainCharacter gameCharacter;
	private OutputController oc;
	
	/*******************************************************************************
	* Submodule: ChooseWeapon                                                      *
	* Import:    inGameCharacter (MainCharacter), inUI (UserInterface)             *
	* Export:    None                                                              *
	* Assertion: Alternate Constructor for ChooseWeapon.				           *
	*******************************************************************************/
	public ChooseWeapon(MainCharacter inGameCharacter, OutputController inOC)
	{
		gameCharacter = inGameCharacter;
		oc = inOC;
	}
	
	/*******************************************************************************
	* Submodule: doSelection                                                       *
	* Import:    None                                                  			   *
	* Export:    None                                                              *
	* Assertion: Overriding Parent Selection as a part of the Strategy Pattern.    *
	*******************************************************************************/
	@Override
	public void doSelection()
	{
		boolean done = false;
		int choice;
		gameCharacter.displayInventory();
		//Get the users choice.
		choice = oc.getChoice("\nWhich weapon do you want to equip?");
		while (!done)
		{
			try
			{
				//Subtract 1 from Choice for 0 based indexing.
				gameCharacter.setMainWeapon(choice-1);
				done = true;
				oc.printString("\n" + gameCharacter.getWeapon().getItemName() + " successfully equipped.");
			}
			catch (MainCharacterException mce)
			{
				oc.printString("Re-enter Choice, that was an invalid weapon. ");
				choice = oc.getChoice("Press 0 to exit.");
			}
			catch (IndexOutOfBoundsException invalidChoice)
			{
				oc.printString("Invalid Choice - Choose Weapon.");
			}
			catch (NullPointerException npe)
			{
				oc.printString("Can't set weapon, doesn't exist.");
			}
			
			if (choice == 0)
			{
				done = true;
			}
		}
	}
}