/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         ChooseCharacterName.java                                      *
* Purpose:          One of the 5 Strategies, responsible for setting character    *
*                   name. 														  *          
* Unit:             OOSE                                                          *
* Last Modified:    27/04/2020                                                    *
**********************************************************************************/
package Controller.SelectionStrategy;

//Import Custom Packages
import Controller.OutputController;
import Model.MainCharacter;

//Import Java Packages
import java.util.*;
public class ChooseCharacterName implements Selection
{
	private MainCharacter gameCharacter;
	private OutputController oc;
	
	public ChooseCharacterName(MainCharacter mCharacter, OutputController inOC)
	{
		oc = inOC;
		gameCharacter = mCharacter;
	}
	
	/*******************************************************************************
	* Submodule: doSelection                                                       *
	* Import:    None                                                              *
	* Export:    None                                                              *
	* Assertion: Overriding Parent Selection as part of Strategy Pattern.          *
	*******************************************************************************/
	@Override
	public void doSelection()
	{
		//Set the character name.
		gameCharacter.setName(oc.getCharacterName());
	}
}