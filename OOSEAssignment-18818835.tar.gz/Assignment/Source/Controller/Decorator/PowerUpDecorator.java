/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         PowerUpDecorator.java             			                  *
* Purpose:          Handles all PowerUpDecorator functionality.		              *
* Unit:             OOSE                                                          *
* Last Modified:    28/04/2020                                                    *
**********************************************************************************/
package Controller.Decorator;

//Import Custom Packages
import Controller.Exceptions.DecoratorException;
import Model.Item.Weapon;
  
public class PowerUpDecorator extends EnchantmentDecorator
{
	//The price that the Decorator adds to the Weapon.
	private int price;
	
	public PowerUpDecorator(Weapon innerWeapon) throws DecoratorException
	{
		super(innerWeapon);
		price = 10;
	}
	
	/*******************************************************************************
	* Submodule: calcDamage          	                                           *
	* Import:    None					    									   *
	* Export:    Integer                                                           *
	* Assertion: Decorates the Weapon with Extra Damage.     				       *
	*******************************************************************************/
	@Override
	public int calcDamage()
	{
		return ((int)(innerWeapon.calcDamage() * 1.1)); 				//Need to check about whether this is rounding
	}
	
	/*******************************************************************************
	* Submodule: getCost          	                                               *
	* Import:    None									    					   *
	* Export:    Integer                                                           *
	* Assertion: Decorates the cost with the price of this Decorator			   *
	*******************************************************************************/
	@Override
	public int getCost()
	{
		return (innerWeapon.getCost() + price);
	}
	
	@Override
	public String toString()
	{
		return ("Item Name: " + innerWeapon.getItemName() + ", Cost: " + getCost() + ", Minimum Damage: " + ((int)innerWeapon.getMinDamage() * 1.1) + ", Maxiumum Damage: " + ((int)innerWeapon.getMaxDamage() * 1.1) + ", Damage Type: " + innerWeapon.getDamageType() + ", Weapon Type: " + innerWeapon.getWeaponType());
	}
}