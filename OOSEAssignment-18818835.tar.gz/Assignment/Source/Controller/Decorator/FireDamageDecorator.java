/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         FireDamageDecorator.java             			              *
* Purpose:          Handles all FireDamageDecorator functionality.	         	  *
* Unit:             OOSE                                                          *
* Last Modified:    28/04/2020                                                    *
**********************************************************************************/
package Controller.Decorator;

//Import Custom Packages
import Controller.Exceptions.DecoratorException;
import Model.Item.Weapon;
  
public class FireDamageDecorator extends EnchantmentDecorator
{
	//The price that the Decorator adds to the Weapon.
	private int price;
	
	public FireDamageDecorator(Weapon innerWeapon) throws DecoratorException
	{
		super(innerWeapon);
		price = 20;
	}
	
	/*******************************************************************************
	* Submodule: calcDamage          	                                           *
	* Import:    None					    									   *
	* Export:    Integer                                                           *
	* Assertion: Decorates the Weapon with Fire Damage.     				       *
	*******************************************************************************/
	@Override 
	public int calcDamage()
	{
		return (innerWeapon.calcDamage() + getRandomValue(5,10)); 
	}

    /*******************************************************************************
	* Submodule: getCost          	                                               *
	* Import:    None									    					   *
	* Export:    Integer                                                           *
	* Assertion: Decorates the cost with the price of this Decorator			   *
	*******************************************************************************/
	@Override
	public int getCost()
	{
		return (innerWeapon.getCost() + price);
	}

	@Override
	public String toString()
	{
		return ("Item Name: " + innerWeapon.getWeaponName() + ", Cost: " + getCost() + ", Minimum Damage: " + innerWeapon.getMinDamage() + " + 5 - 10 Fire Bonus, Maxiumum Damage: " + innerWeapon.getMaxDamage() + " + 5 - 10 Fire Bonus, Damage Type: " + innerWeapon.getDamageType() + ", Weapon Type: " + innerWeapon.getWeaponType());
	}
}