/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         PlusTwoDecorator.java             			                  *
* Purpose:          Handles all PlusTwoDecorator functionality.		              *
* Unit:             OOSE                                                          *
* Last Modified:    28/04/2020                                                    *
**********************************************************************************/
package Controller.Decorator;

//Import Custom Packages
import Controller.Exceptions.DecoratorException;
import Model.Item.Weapon;
  
public class PlusTwoDecorator extends EnchantmentDecorator
{
	//The price that the Decorator adds to the Weapon.
	private int price;
	
	public PlusTwoDecorator(Weapon innerWeapon) throws DecoratorException
	{	
		super(innerWeapon);
		price = 5;
	}
	
	/*******************************************************************************
	* Submodule: calcDamage          	                                           *
	* Import:    None					    									   *
	* Export:    Integer                                                           *
	* Assertion: Decorates the Weapon with Extra Damage.     				       *
	*******************************************************************************/
	@Override
	public int calcDamage()
	{
		return (innerWeapon.calcDamage() + 2); 
	}

	/*******************************************************************************
	* Submodule: getCost          	                                               *
	* Import:    None									    					   *
	* Export:    Integer                                                           *
	* Assertion: Decorates the cost with the price of this Decorator			   *
	*******************************************************************************/
	@Override
	public int getCost()
	{
		return (innerWeapon.getCost() + price);
	}
	
	@Override
	public String toString()
	{
		return ("Item Name: " + innerWeapon.getWeaponName() + ", Cost: " + getCost() + ", Minimum Damage: " + (innerWeapon.getMinDamage() + 2) + ", Maxiumum Damage: " + (innerWeapon.getMaxDamage() + 2) + ", Damage Type: " + innerWeapon.getDamageType() + ", Weapon Type: " + innerWeapon.getWeaponType());
	}
}