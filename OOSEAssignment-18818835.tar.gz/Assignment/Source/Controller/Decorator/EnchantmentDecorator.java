/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         EnchantmentDecorator.java             			              *
* Purpose:          Handles all Parent EnchantmentDecorator functionality.		  *
* Unit:             OOSE                                                          *
* Last Modified:    28/04/2020                                                    *
**********************************************************************************/
package Controller.Decorator;

//Import Custom Packages
import Controller.Exceptions.DecoratorException;
import Model.Item.Weapon;

public abstract class EnchantmentDecorator extends Weapon
{
	//Weapon that the Decorator will be Decorating.
	protected Weapon innerWeapon;
	
	public EnchantmentDecorator(Weapon innerWeapon) throws DecoratorException
	{
		if (innerWeapon == null)
		{
			throw new DecoratorException("This Enchantment is too strong for this weapon.");
		}
		else
		{
			this.innerWeapon = innerWeapon;
		}
	}
	
	/*******************************************************************************
	* Submodule: getWeaponType         	                                           *
	* Import:    None									    					   *
	* Export:    String                                                            *
	* Assertion: Returns the Weapon's value from the same method.    			   *
	*******************************************************************************/
	@Override
	public String getWeaponType()
	{
		return innerWeapon.getWeaponType();
	}
	
	/*******************************************************************************
	* Submodule: getMinDamage          	                                           *
	* Import:    None									    					   *
	* Export:    Integer                                                           *
	* Assertion: Returns the Weapon's value from the same method.    			   *
	*******************************************************************************/
	@Override
	public int getMinDamage()
	{
		return innerWeapon.getMinDamage();
	}
	
	/*******************************************************************************
	* Submodule: getMaxDamage         	                                           *
	* Import:    None									    					   *
	* Export:    Integer                                                           *
	* Assertion: Returns the Weapon's value from the same method.    			   *
	*******************************************************************************/
	@Override
	public int getMaxDamage()
	{
		return innerWeapon.getMaxDamage();
	}
	
	/*******************************************************************************
	* Submodule: calcDamage          	                                           *
	* Import:    None									    					   *
	* Export:    Integer                                                           *
	* Assertion: Returns the Weapon's value from the same method.    			   *
	*******************************************************************************/
	@Override
	public int calcDamage()
	{
		return innerWeapon.calcDamage();
	}
	
	/*******************************************************************************
	* Submodule: getDamageType         	                                           *
	* Import:    None									    					   *
	* Export:    Strung                                                            *
	* Assertion: Returns the Weapon's value from the same method.    			   *
	*******************************************************************************/
	@Override
	public String getDamageType()
	{
		return innerWeapon.getDamageType();
	}
	
	/*******************************************************************************
	* Submodule: getItemType          	                                           *
	* Import:    None									    					   *
	* Export:    String                                                            *
	* Assertion: Returns the Weapon's value from the same method.    			   *
	*******************************************************************************/
	@Override
	public String getItemType()
	{
		return innerWeapon.getItemType();
	}
	
	/*******************************************************************************
	* Submodule: getIdentifier        	                                           *
	* Import:    None									    					   *
	* Export:    Integer                                                           *
	* Assertion: Returns the Weapon's value from the same method.    			   *
	*******************************************************************************/
	@Override 
	public int getIdentifier()
	{
		return innerWeapon.getIdentifier();
	}
	
	/*******************************************************************************
	* Submodule: toString             	                                           *
	* Import:    None									    					   *
	* Export:    String                                                            *
	* Assertion: Returns the Weapon's value from the same method.    			   *
	*******************************************************************************/
	@Override
	public String toString()
	{
		return innerWeapon.toString();
	}
	
	/*******************************************************************************
	* Submodule: getCost             	                                           *
	* Import:    None									    					   *
	* Export:    Integer                                                           *
	* Assertion: Returns the Weapon's value from the same method.    			   *
	*******************************************************************************/
	@Override
	public int getCost()
	{
		return innerWeapon.getCost();
	}		
}