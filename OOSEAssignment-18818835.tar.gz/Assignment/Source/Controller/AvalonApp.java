/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         AvalonApp.java                                                *
* Purpose:          Main Run file for Game.										  *
* Unit:             OOSE                                                          *
* Last Modified:    27/04/2020                                                    *
**********************************************************************************/
package Controller;

//Import Custom Packages
import Controller.Exceptions.CreateMainCharacterException;
import Controller.Exceptions.CreateItemException;
import Controller.Factories.MainCharacterFactory;
import Controller.Factories.ItemFactory;
import View.UserInterface;
import FileIO.ReadFile;
import Model.MainCharacter;
import Model.Item.*;

//Import Custom Packages
import java.util.*;

public class AvalonApp
{
    public static void main(String[] args)
    {
		System.out.print("\033[H\033[2J");
		ItemFactory itemFactory = new ItemFactory();
		MainCharacterFactory mcFactory = new MainCharacterFactory();
		try
		{
			Weapon newWeapon = itemFactory.CreateBasicWeapon();
			Armour newArmour = itemFactory.CreateBasicArmour();
			MainCharacter gameCharacter = mcFactory.CreateDefaultMainCharacter(newWeapon, newArmour);
			UserInterface ui = new UserInterface(gameCharacter);				
			gameCharacter.add(ui);				//Add UserInterface as an observer to MainCharacter
			OutputController oc = new OutputController(ui);
			MenuController mc = new MenuController();
		
			try
			{
				mc.run(gameCharacter, ui, itemFactory, oc);
			}
			catch (Exception e)
			{
				e.printStackTrace();
				System.out.println("Exception");
			}
		}
		catch (CreateItemException cie)
		{
			System.out.println(cie.getMessage() + " Closing Program.");
		}
		catch (CreateMainCharacterException cmce)
		{
			System.out.println(cmce.getMessage() + " Closing Program.");
		}
		catch (NullPointerException npe)
		{
			System.out.println("Unexpected Error - Closing Program.");
		}
	}
}

