/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         ReadFile.java                                                 *
* Purpose:          Handles all File Reading.									  *
* Unit:             OOSE                                                          *
* Last Modified:    27/04/2020                                                    *
**********************************************************************************/
package FileIO;

//Import Custom Packages
import Controller.Exceptions.CreateItemException;
import Controller.OutputController;

//Import Java Packages
import java.util.*;
import java.io.*;

public class ReadFile
{
	private OutputController oc;
	
	public ReadFile(OutputController inOC)
	{
		oc = inOC;
	}
	
	/*******************************************************************************
	* Submodule: readCSVFile                                                       *
	* Import:    None                                                              *
	* Export:    fileContents (ArrayList<String>)                                  *
	* Assertion: Reads Items from CSV and adds enchantments to Shop.               *
	*******************************************************************************/
	public ArrayList<String> readCSVFile()
	{
		String Line;
		
		//sStore the file contents.
		ArrayList<String> fileContents = new ArrayList<String>();
		
		//Declare the Reader.
		BufferedReader bReader = null;
		
		try
		{
			//Initialize the reader.
			bReader = new BufferedReader(new FileReader("Inventory.txt"));
			
			//Get the current line.
			String line = bReader.readLine();
			
			//Check if the line is null.
			while (line != null)
			{
				//If it isn't add to the collection.
				fileContents.add(line);
				
				//Get the next line.
				line = bReader.readLine();
			}
			
			//Close the stream.
			bReader.close();
			
			//Add the enchantments. These could be just as easily added to the text file.
			//That's why I used a collection so that either way you could add an enchantment below or in the txt
			fileContents.add("Enchantment, Damage + 2, Cost: 5, Add 2 to Attack Damage");
			fileContents.add("Enchantment, Damage + 5, Cost: 10, Add 10 to Attack Damage");
			fileContents.add("Enchantment, Fire Damage, Cost: 20, Adds between 5 and 10 to Attack Damage");
			fileContents.add("Enchantment, Power-Up, Cost: 10, Multiples Attack Damage by 1.1.");			
		}
		catch (IOException ioe)
		{
			try 
			{
				//Try and close the stream gracefully.
				if (bReader != null)
				{
					//Close the stream.
					bReader.close();
				}
			}
			catch (IOException ioe2)
			{
				//Error Message.
				oc.printString("Can't close file. - File Reader. ");
			}
		}
		finally	//Worst case if we can't close.
		{
			try
			{
				//Try one last time to close.
				if (bReader != null)
				{
					//Close the Stream.
					bReader.close();
				}
			}
			catch (IOException ioe3)
			{
				oc.printString("Can't close file. - File Reader. ");
			}
		}
		//Return the fileContents
		return fileContents;
	}
}