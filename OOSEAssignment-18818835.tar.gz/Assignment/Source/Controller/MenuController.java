/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         MenuController.java                                           *
* Purpose:          Responsible for the adding Strategies and handling Menu.	  * 
* Unit:             OOSE                                                          *
* Last Modified:    27/04/2020                                                    *
**********************************************************************************/
package Controller;

//Import Custom Packages
import Controller.BattleStrategy.AttackStrategy.*;
import Controller.BattleStrategy.PotionStrategy.*;
import Controller.SelectionStrategy.*;
import Controller.Factories.*;
import View.UserInterface;
import FileIO.ReadFile;
import Model.MainCharacter;

//Import Java Packages
import java.util.*;

public class MenuController
{
	private HashMap<Integer, Selection> selections;
	private Selection goToShop;
	private Selection chooseCharacterName;
	private Selection chooseWeapon;
	private Selection chooseArmour;
	private Selection startBattle;
	
	/*******************************************************************************
	* Submodule: run                                                               *
	* Import:    gameCharacter (MainCharacter), ui (UserInterface)                 *
	* Export:    None                                                              *
	* Assertion: Initializes the Strategy Pattern.                                 *
	*******************************************************************************/
	public void run(MainCharacter gameCharacter, UserInterface ui, ItemFactory inItemFactory, OutputController inOC)
	{
		ui.displayUserStatistics();											//Initial Display Method for User Statistics.
		//Create the Factories
		EnemyFactory ef = new EnemyFactory();
		RoundFactory rf = new RoundFactory();
		EnchantmentFactory enchantmentFactory = new EnchantmentFactory();
		
		//Create the Battle Strategies
		MainCharacterAttackStrategy mainCharacterAttackStrategy = new MainCharacterAttackStrategy();
		EnemyAttackStrategy enemyAttackStrategy = new EnemyAttackStrategy();
		HealingPotionStrategy healingPotionStrategy = new HealingPotionStrategy();
		ExplosivePotionStrategy explosivePotionStrategy = new ExplosivePotionStrategy();
		
		//Create the Selections Strategies
		ArrayList<String> shopInventory = ((new ReadFile(inOC).readCSVFile()));	
		goToShop = new Shop(shopInventory, inOC, gameCharacter, inItemFactory, enchantmentFactory);
		chooseCharacterName = new ChooseCharacterName(gameCharacter, inOC);
		chooseWeapon = new ChooseWeapon(gameCharacter, inOC);
		chooseArmour = new ChooseArmour(gameCharacter, inOC);
		startBattle = new StartBattle(gameCharacter, ef, rf, mainCharacterAttackStrategy, enemyAttackStrategy, healingPotionStrategy, explosivePotionStrategy, inOC);
		selections = new HashMap<Integer, Selection>();
		selections.put(1, goToShop);										//Creates new GoToShop Object as a Selections object.
		selections.put(2, chooseCharacterName);								//Creates new ChooseCharacterName Object as a Selections object.
		selections.put(3, chooseWeapon);									//Creates new ChooseWeapon Object as a Selections object.
		selections.put(4, chooseArmour);									//Creates new ChooseArmour Object as a Selections object.
		selections.put(5, startBattle);										//Creates new StartBattle Object as a Selections object.
		ui.displayMenu(selections);	
		
	}
}

