/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         OutputController.java                                         *
* Purpose:          Responsible for the adding Strategies and handling Menu.	  * 
* Unit:             OOSE                                                          *
* Last Modified:    31/05/2020                                                    *
**********************************************************************************/
package Controller;

//Import Custom Packages
import View.UserInterface;
import Model.Item.Item;

//Import Java Packages
import java.util.*;

public class OutputController
{
	private UserInterface ui;
	
	public OutputController(UserInterface inUI)
	{
		ui = inUI;
	}
		
	/*******************************************************************************
	* Submodule: printString                                                       *
	* Import:    inString (String)                                                 *
	* Export:    None                                                              *
	* Assertion: Calls the respective User Interface Method.				       *
	*******************************************************************************/
	public void printString(String inString)
	{
		ui.displayString(inString);
	}
	
	/*******************************************************************************
	* Submodule: getChoice                                                         *
	* Import:    inString (String)                                                 *
	* Export:    None                                                              *
	* Assertion: Calls the respective User Interface Method.				       *
	*******************************************************************************/
	public int getChoice(String inString)
	{
		return ui.getChoice(inString);
	}
	
	/*******************************************************************************
	* Submodule: continueScreen                                                    *
	* Import:    None                                                              *
	* Export:    None                                                              *
	* Assertion: Calls the respective User Interface Method.				       *
	*******************************************************************************/
	public void continueScreen()
	{
		ui.continueScreen();
	}
	
	/*******************************************************************************
	* Submodule: getCharacterName                                                  *
	* Import:    None                                                              *
	* Export:    String                                                            *
	* Assertion: Calls the respective User Interface Method.				       *
	*******************************************************************************/
	public String getCharacterName()
	{
		return ui.getCharacterName();
	}
	
	/*******************************************************************************
	* Submodule: displayShop                                                       *
	* Import:    inventory (ArrayList of Items)                                    *
	* Export:    Integer                                                           *
	* Assertion: Calls the respective User Interface Method.				       *
	*******************************************************************************/
	public int displayShop(ArrayList<String> inventory)
	{
		return ui.displayShop(inventory);
	}
	
	/*******************************************************************************
	* Submodule: displayCharacterInventory                                         *
	* Import:    inventory (ArrayList of Items)                                    *
	* Export:    None                                                              *
	* Assertion: Calls the respective User Interface Method.				       *
	*******************************************************************************/
	public void displayCharacterInventory(List<Item> inventory)
	{
		ui.displayCharacterInventory(inventory);
	}
}
		
