/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         ItemFactory.java                                              *
* Purpose:          Responsible for all Item Creation via Factory Pattern. 		  *
* Unit:             OOSE                                                          *
* Last Modified:	27/04/2020                                                    *
**********************************************************************************/
package Controller.Factories;

//Import Custom Packages
import Model.Item.*;
import Controller.Exceptions.CreateItemException;
import Controller.Exceptions.PotionException;
import Controller.Exceptions.ArmourException;
import Controller.Exceptions.WeaponException;
import Controller.Exceptions.ItemException;

//Import Java Packages
import java.util.*;

public class ItemFactory
{
	//Easy way to keep track of which item is which.
	private int serialNumber;
	
	public ItemFactory()
	{
		serialNumber = 0;
	}
	
	/*******************************************************************************
	* Submodule: CreateItem                                                        *
	* Import:    line (String)                                                     *
	* Export:    newItem (Item)                                                    *
	* Assertion: Creates and Item depending on the type of the line.               *
	*******************************************************************************/
	public Item CreateItem(String line) throws CreateItemException
	{
		//Split the line
		String[] parts = line.split(",");
		String name;
		//Check the itemType for potiononly
		char itemType = parts[0].charAt(0);
		int cost;
		Item newItem = null;
		try
		{
			//This case is for if its a weapon
			if ((parts.length < 8) || (parts.length > 0))		
			{

				name = parts[1].trim();
				cost = Integer.parseInt((parts[4]).trim());
				if (itemType == 'W')
				{
					//Organise and create the item from its fields.
					int minDamage, maxDamage;
					String damageType, weaponType;
					minDamage = Integer.parseInt((parts[2]).trim());
					maxDamage = Integer.parseInt((parts[3]).trim());
					damageType = parts[5].trim();
					weaponType = parts[6].trim();	
					newItem = new Weapon(name, minDamage, maxDamage, cost, damageType, weaponType, serialNumber);				
					serialNumber++;
				}
				else if (itemType == 'A')	//A piece of armour
				{
					//Organise and create the item from its fields.
					int minDefence, maxDefence;
					String material;
					minDefence = Integer.parseInt((parts[2]).trim());
					maxDefence = Integer.parseInt((parts[3]).trim());
					material = parts[5].trim();
					newItem = new Armour(name, minDefence, maxDefence, cost, material, serialNumber);
					serialNumber++;
				}
				else if (itemType == 'P') //A potion
				{
					//Organise and create the item from its fields.
					int minEffect, maxEffect;
					char type;
					minEffect = Integer.parseInt((parts[2]).trim());
					maxEffect = Integer.parseInt((parts[3]).trim());
					type = parts[5].trim().charAt(0);					
					newItem = new Potion(name, minEffect, maxEffect, cost, type, serialNumber);
					serialNumber++;					
				}
				else
				{
					throw new CreateItemException("Item cannot be created from given types - CreateItem.");
				}
			}
			else
			{
				throw new CreateItemException("Item cannot be created invalid length - CreateItem.");
			}
		}
		catch (NumberFormatException nfe)
		{
			throw new CreateItemException("String does not contain an integer - CreateItem.");
		}
		catch (IndexOutOfBoundsException oob)
		{
			throw new CreateItemException("Index is out of bounds when converting Type - CreateItem.");
		}
		catch (NullPointerException npe)
		{
			throw new CreateItemException("Invalid Value NPE. - CreateItem. ");
		}
		catch (ItemException ie)
		{
			throw new CreateItemException(ie.getMessage());
		}
		catch (WeaponException we)
		{
			throw new CreateItemException(we.getMessage());
		}
		catch (ArmourException ae)
		{
			throw new CreateItemException(ae.getMessage());
		}
		catch (PotionException pe)
		{
			throw new CreateItemException(pe.getMessage());
		}
		return newItem;
	}
	
	/*******************************************************************************
	* Submodule: CreateBasicArmour     	                                           *
	* Import:    None									    					   *
	* Export:    newArmour (Armour)                                                *
	* Assertion: Sole Constructor for the Basic/Cheapest Armour.    			   *
	*******************************************************************************/
	public Armour CreateBasicArmour() throws CreateItemException
	{
		Armour newArmour = null;
		try
		{
			newArmour = new Armour("Leather Armour", 5, 15, 10, "Leather", serialNumber);
			serialNumber++;
		}
		catch (ArmourException ae)
		{
			throw new CreateItemException(ae.getMessage());
		}
		catch (ItemException ie)
		{
			throw new CreateItemException(ie.getMessage());
		}
		
		return newArmour;
	}
	
	/*******************************************************************************
	* Submodule: CreateBasicWeapon     	                                           *
	* Import:    None									    					   *
	* Export:    newWeapon (Weapon)                                                *
	* Assertion: Sole Constructor for the Basic/Cheapest Weapon.    			   *
	*******************************************************************************/
	public Weapon CreateBasicWeapon() throws CreateItemException
	{
		Weapon newWeapon = null;
		try
		{
			newWeapon = new Weapon("Short Sword", 5, 9, 10, "slashing", "Sword", serialNumber);	
			serialNumber++;
		}
		catch (WeaponException ae)
		{
			throw new CreateItemException(ae.getMessage());
		}
		catch (ItemException ie)
		{
			throw new CreateItemException(ie.getMessage());
		}
		return newWeapon;
	}
}