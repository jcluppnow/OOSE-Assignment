/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         MainCharacterFactory.java                                     *
* Purpose:          Responsible for all MainCharacter Creation via the Factory    *
*                   Pattern.													  *
* Unit:             OOSE                                                          *
* Last Modified:    30/05/2020                                                    *
**********************************************************************************/
package Controller.Factories;

//Import Custom Packages
import Controller.Exceptions.CreateMainCharacterException;
import Controller.Exceptions.MainCharacterException;
import Model.MainCharacter;
import Model.Item.Weapon;
import Model.Item.Armour;

//Import Java Packages

public class MainCharacterFactory
{
	public MainCharacter CreateDefaultMainCharacter(Weapon inWeapon, Armour inArmour) throws CreateMainCharacterException
	{
		//Attempt to create a MainCharacter
		MainCharacter gameCharacter = null;
		try
		{
			gameCharacter = new MainCharacter(inWeapon, inArmour);
		}
		catch (MainCharacterException mce)
		{
			throw new CreateMainCharacterException(mce.getMessage());
		}
		return gameCharacter;
	}
}