/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         RoundDataFactory.java                                         *
* Purpose:          Responsible for all RoundData Creation via the Factory        *
*                   Pattern.													  *
* Unit:             OOSE                                                          *
* Last Modified:    25/05/2020                                                    *
**********************************************************************************/
package Controller.Factories;

//Import Custom Packages
import Model.RoundData;

//Import Java Packages

public class RoundFactory
{
	/*******************************************************************************
	* Submodule: CreateDefaultRound   	                                           *
	* Import:    inRoundNumber (Integer) 					   					   *
	* Export:    round (RoundData)                                                 *
	* Assertion: Sole constructory for the Round Object.		    			   *
	*******************************************************************************/
	public RoundData CreateDefaultRound(int inRoundNumber)
	{
		RoundData round = new RoundData(inRoundNumber);
		return round;
	}
}