/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         CreateEnchantmentException.java                               *
* Purpose:          Handles all CreateEnchantmentException functionality.	      *
* Unit:             OOSE                                                          *
* Last Modified:    27/04/2020                                                    *
**********************************************************************************/
package Controller.Exceptions;

public class CreateEnchantmentException extends Exception
{
	public CreateEnchantmentException(String message, Throwable cause)
	{
		super(message, cause);
	}
	
	public CreateEnchantmentException(String message)
	{
		super(message);
	}
}

