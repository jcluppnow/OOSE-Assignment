/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         CreateMainCharacterException.java                             *
* Purpose:          Handles all CreateMainCharacterException functionality.		  *
* Unit:             OOSE                                                          *
* Last Modified:    30/04/2020                                                    *
**********************************************************************************/
package Controller.Exceptions;

public class CreateMainCharacterException extends Exception
{
	public CreateMainCharacterException(String message, Throwable cause)
	{
		super(message, cause);
	}
	
	public CreateMainCharacterException(String message)
	{
		super(message);
	}
}

