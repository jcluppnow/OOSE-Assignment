/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         DecoratorException.java                                       *
* Purpose:          Handles all DecoratorException functionality.				  *
* Unit:             OOSE                                                          *
* Last Modified:    27/04/2020                                                    *
**********************************************************************************/
package Controller.Exceptions;

public class DecoratorException extends Exception
{
	public DecoratorException(String message, Throwable cause)
	{
		super(message, cause);
	}
	
	public DecoratorException(String message)
	{
		super(message);
	}
}

