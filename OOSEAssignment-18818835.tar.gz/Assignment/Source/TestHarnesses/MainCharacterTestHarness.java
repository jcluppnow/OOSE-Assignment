/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:        	MainCharacterTestHarness.java                                 *
* Purpose:          Tests the properties of the MainCharacter Model.			  *
* Unit:             OOSE                                                          *
* Last Modified:    18/05/2020                                                    *
**********************************************************************************/
package TestHarnesses;

//Import Custom Packages
import Controller.Exceptions.MainCharacterException;
import Controller.Exceptions.ArmourException;
import Controller.Exceptions.WeaponException;
import Controller.Exceptions.ItemException;
import Model.MainCharacter;
import Model.Item.*;

public class MainCharacterTestHarness
{
	public static void main(String args[])
	{
		Armour newArmour = null;
		
		try
		{
			newArmour = new Armour("Leather Armour", 5, 15, 10, "Leather", 0);
		}
		catch (ItemException ie)
		{
			System.out.println(ie.getMessage());
		}
		catch (ArmourException ae)
		{
			System.out.println(ae.getMessage());
		}
		
		Weapon newWeapon = null;
		try
		{
			newWeapon = new Weapon("Short Sword", 5, 9, 10, "slashing", "Sword", 1);
		}
		catch (ItemException ie)
		{
			System.out.println(ie.getMessage());
		}
		catch (WeaponException we)
		{
			System.out.println(we.getMessage());
		}
		
		MainCharacter gameCharacter = null;
		try
		{
			gameCharacter = new MainCharacter(newWeapon, newArmour);
		}
		catch (MainCharacterException mce)
		{
			System.out.println(mce.getMessage());
		}
		
		try
		{
			System.out.println("Game Character Details \n" + gameCharacter.toString());
			
			System.out.println("Max Health: " + gameCharacter.getMaxHealth());
			
			System.out.println("Current Health: " + gameCharacter.getCurrentHealth());
			
			System.out.println("Funds: " + gameCharacter.getFunds());
			
			System.out.println("Name: " + gameCharacter.getName());
			
			System.out.println("Weapon Details:  \n\tMin Damage: " + gameCharacter.getWeapon().getMinDamage() + "\n\tMax Damage: " + gameCharacter.getWeapon().getMaxDamage() + "\n\tCalc Damage: " + gameCharacter.getWeapon().calcDamage() + "\n\tDamage Type: " + gameCharacter.getWeapon().getDamageType() + "\n\tItem Type: " + gameCharacter.getWeapon().getItemType());
		}
		catch (NullPointerException npe)
		{
			System.out.println(npe.getMessage());
		}
	}
}
		
