/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         RoundData.java                                		          *
* Purpose:          Handles all characteristics of RoundData Class.				  *
* Unit:             OOSE                                                          *
* Last Modified:    25/05/2020                                                    *
**********************************************************************************/
package Model;

//Import Java Packages
import java.util.ArrayList;

public class RoundData
{
	private ArrayList<String> log;
	private int roundNumber;
	
	public RoundData(int inRoundNumber)
	{
		log = new ArrayList<String>();
		roundNumber = inRoundNumber;
	}
	
	public RoundData(ArrayList<String> log, int inRoundNumber)
	{
		this.log = log;
		roundNumber = inRoundNumber;
	}
	
	/*******************************************************************************
	*                                 ACCESSORS                                    *
	********************************************************************************
	*              Responsible for accessing all RoundData classfields.            *
	*******************************************************************************/
	public String toString()
	{
		String logString = "";
		for (String line : log)
		{
			logString = logString + "\n" + line;
		}
		return logString;
	}
	
	public ArrayList<String> getLog()
	{
		return log;
	}
	
	public int getRoundNumber()
	{
		return roundNumber;
	}
	
	/*******************************************************************************
	*                                MUTATORS                                      *
	********************************************************************************
	*              Responsible for setting all RoundData classfields.              *
	*******************************************************************************/
	public void addAction(String inAction)
	{
		if (validateString(inAction))
		{
			log.add(inAction);
		}
	}
	
	/*******************************************************************************
	*                           PRIVATE SUBMODULES                                 *
	********************************************************************************
	*           Responsible for all private submodules within RoundData.           *
	*******************************************************************************/
	private boolean validateString(String inString)
	{
		boolean validString = true;
		String emptyString = "";
		
		if (emptyString.equals(inString))
		{
			validString = false;
		}
		return validString;
	}
}
	
	
	