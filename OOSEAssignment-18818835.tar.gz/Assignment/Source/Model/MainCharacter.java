/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         MainCharacter.java                                            *
* Purpose:          Handles all MainCharacter functionality.					  *
* Unit:             OOSE                                                          *
* Last Modified:    27/04/2020                                                    *
**********************************************************************************/
package Model;

//Import Custom Packages
import Controller.Exceptions.MainCharacterException;
import Controller.MainCharacterObservable;
import View.UserInterface;
import View.MainCharacterObserver;
import Model.Item.Item;
import Model.Item.Armour;
import Model.Item.Weapon;

//Import Java Packages
import java.util.*;

public class MainCharacter implements MainCharacterObservable
{
	//Classfields
	private ArrayList<MainCharacterObserver> observers;
	private String name;
	private int maxHealth;
	private int currentHealth;
	private List<Item> inventory;
	private Weapon mainWeapon;
	private Armour mainArmour;
	private int gold;
	private boolean alive;

	
	/*******************************************************************************
	* Submodule: MainCharacter                                                     *
	* Import:    None 															   *
	* Export:    None                                                              *
	* Assertion: Default Constructor for MainCharacter.					           *
	*******************************************************************************/
	public MainCharacter(Weapon inWeapon, Armour inArmour) throws MainCharacterException
	{
		if (inWeapon == null || inArmour == null)
		{
			if (inWeapon == null)
			{
				throw new MainCharacterException("Invalid Weapon - Main Character.");
			}
			else
			{
				throw new MainCharacterException("Invalid Armour - Main Character.");
			}
		}
		else
		{
			observers = new ArrayList<MainCharacterObserver>();
			name = "Steve";
			maxHealth = 30;
			currentHealth = maxHealth;
			mainWeapon = inWeapon;
			mainArmour = inArmour;
			inventory = new ArrayList<Item>();
			/*inventory.add(mainWeapon);
			inventory.add(mainArmour);*/
			gold = 100;
			alive = true;
		}
	}
	
	/*******************************************************************************
	*                                MUTATORS                                      *
	********************************************************************************
	*              Responsible for setting all MainCharacter classfields.          *
	*******************************************************************************/
	public void add(MainCharacterObserver inObserver)
	{
		observers.add(inObserver);
	}
	
	public void setName(String inName)
	{
		name = inName;
		notifyObservers();
	}
	
	public void heal(int amount)
	{
		currentHealth = currentHealth + amount;
		if (currentHealth > maxHealth)
		{
			currentHealth = maxHealth;
		}
		notifyObservers();
	}
	
	public void setAlive(boolean inStatus)
	{
		alive = inStatus;
	}
	
	public void addToInventory(Item inItem)
	{
		inventory.add(inItem);
	}
	
	public void removeFromInventory(int index)
	{
		inventory.remove(index);
	}
	
	public void setMainWeapon(int choice) throws MainCharacterException
	{
		//Justifiable Down Casting, guarantees that the item is of type Weapon.
		Item item = inventory.remove(choice);
		if (item.getItemType().equals("Weapon"))
		{
			inventory.add((Item)mainWeapon);
			mainWeapon =  (Weapon) item;
			notifyObservers();
		}
		else
		{
			inventory.add(item);
			throw new MainCharacterException("Invalid Type: " + item.getItemType() + "\nMust be of type Weapon."); 
		}
	}
	
	public void setMainWeapon(Weapon inWeapon) throws MainCharacterException
	{
		if (inWeapon.getItemType().equals("Weapon"))
		{
			mainWeapon = inWeapon;
		}
		else
		{
			throw new MainCharacterException("Invalid Type: " + inWeapon.getItemType() + "\n Must be of type Weapon.");
		}
	}
	
	public void setMainArmour(int choice) throws MainCharacterException
	{
		//Justifiable Down Casting, guarantees that the item is of type Weapon.
		Item item = inventory.remove(choice);
		if (item.getItemType().equals("Armour"))
		{
			inventory.add((Item)mainArmour);
			mainArmour =  (Armour)item;
			notifyObservers();
		}
		else
		{
			inventory.add(item);
			throw new MainCharacterException("Invalid Type: " + item.getItemType() + "\nMust be of type Armour."); 
		}
	}
	
	public void takeDamage(int amount)
	{
		currentHealth = currentHealth - amount;
		if (currentHealth < 0)
		{
			currentHealth = 0;
		}
		notifyObservers();
	}
	
	public void increaseGold(int amount)
	{
		gold = gold + amount;
		notifyObservers();
	}
	
	public void decreaseGold(int amount)
	{
		gold = gold - amount;
		notifyObservers();
	}
	
	/*******************************************************************************
	*                                 ACCESSORS                                    *
	********************************************************************************
	*             Responsible for accessing all MainCharacter classfields.         *
	*******************************************************************************/
	public void notifyObservers()
	{
		for (MainCharacterObserver observer : observers)
		{
			observer.updateMainCharacter();
		}
	}
	
	public boolean getAlive()
	{
		return alive;
	}
	
	public String toString()
	{
		
		return ("Character Statistics: \n (1) Character Name: " + name + "\n (2) Health: " + currentHealth + "/" + maxHealth + "\n (3) Main Weapon: " + mainWeapon.toString() + "\n (4) Main Armour: " + mainArmour.toString() + "\n (5) Funds: " + gold + " gold\n"); 
	}
	
	public int getMaxHealth()
	{
		return maxHealth;
	}
	
	public int getCurrentHealth()
	{
		return currentHealth;
	}
	
	public List<Item> getInventory()
	{
		return inventory;
	}
	
	public int getFunds()
	{
		return gold;
	}
	
	public String getName()
	{
		return name;
	}
	
	public Item getItemFromInventory(int index)
	{
		return inventory.get(index);
	}
	
	public Weapon getWeapon()
	{
		return mainWeapon;
	}
	
	public int getWeaponSerialNumber()
	{
		return mainWeapon.getIdentifier();
	}
	
	public Item getArmour()
	{
		return mainArmour;
	}
	
	public int getArmourSerialNumber()
	{
		return mainArmour.getIdentifier();
	}
	
	//Calls it's weapon's calcDamage method.
	public int getDamage()
	{
		return mainWeapon.calcDamage();
	}
	
	public String getWeaponName()
	{
		return mainWeapon.getItemName();
	}
	
	//Calls it's armour's calcDefence method.
	public int getDefence()
	{
		return mainArmour.calcDefence();
	}
	
	public void displayInventory()
	{
		UserInterface ui = new UserInterface(this);
		ui.displayCharacterInventory(inventory);
	}
	

}
	
	